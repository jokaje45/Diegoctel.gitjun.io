# DigoCTel 🌱

**Reforestando Moyobamba: Soluciones Comunitarias para la Recuperación Ambiental**

DigoCTel (Digo, Cuido, Transformo el Entorno Local) es una plataforma web interactiva que incentiva la participación ciudadana en actividades de reforestación mediante retos ecológicos y recompensas simbólicas como maseteros y cuadros artesanales.

## Funcionalidades

- 🌳 Retos verdes donde puedes ganar monedas virtuales.
- 🎁 Tienda para canjear monedas por premios ecológicos.
- 📚 Aula ambiental con información sobre conservación.
- 🗣 Foro comunitario para compartir ideas.

## Cómo usar esta página

1. Participa en retos para ganar monedas.
2. Canjea tus monedas en la tienda.
3. Aprende y comparte con tu comunidad.

## Proyecto académico
Facultad de Ingeniería y Arquitectura - Curso: Creatividad e Innovación  
Ciclo: III  
Docente: Alice Cabrera Mendoza  
Estudiantes:
- Anais Mas Vilca  
- Esmeralda Llanos Mestanza  
- Jhonatan Bryan Cueva Hidrogo  
- Karoth Esmeralda Llanos Mestanza  
- Luis Anderson Novoa Gonzales  
- Reátegui Trauco Alexandra