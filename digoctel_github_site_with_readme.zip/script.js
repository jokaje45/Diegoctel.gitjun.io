
let monedas = 0;
function ganarMonedas() {
    monedas += 5;
    document.getElementById('monedas').textContent = monedas;
}
function canjear(costo) {
    if (monedas >= costo) {
        monedas -= costo;
        document.getElementById('monedas').textContent = monedas;
        alert('¡Canje exitoso!');
    } else {
        alert('No tienes suficientes monedas.');
    }
}
